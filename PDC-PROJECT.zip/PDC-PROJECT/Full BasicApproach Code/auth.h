#ifndef AUTH_H
#define AUTH_H

int login(const char *file, const char *username, const char *password);
int signup(const char *file, const char *username, const char *password);

#endif
