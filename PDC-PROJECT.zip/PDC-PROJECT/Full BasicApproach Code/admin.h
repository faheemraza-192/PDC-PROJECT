#ifndef ADMIN_H
#define ADMIN_H

void adminLogin();
void adminMenu();

/* Admin actions */
void viewUsers();
void viewGuides();
void viewBookings();
void confirmBooking();

#endif
