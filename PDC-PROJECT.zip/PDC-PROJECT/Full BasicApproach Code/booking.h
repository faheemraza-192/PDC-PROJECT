#ifndef BOOKING_H
#define BOOKING_H

void viewPackages();
void priceBasedSuggestion();
void destinationSuggestion();
void bookPackage(const char *username);
void viewUserBookings(char *username);

#endif
