#ifndef USER_H
#define USER_H

void userLogin();
void userSignup();
void userMenu(const char *username);

#endif
